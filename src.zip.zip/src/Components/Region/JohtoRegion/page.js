"use client"

import React from "react"
import Header from "@/Components/Header"

const page = () => {
  return (
  <>
    <Header />
    <div>This is Johto Region</div>
  </>
  )
}

export default page