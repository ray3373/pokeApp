import React from "react";

const Region = () => {
return (
	<div>
	<h1>Regions Page</h1>
	</div>
);
};

export default Region;
