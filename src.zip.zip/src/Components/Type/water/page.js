"use client"

import React from "react"
import Header from "@/Components/Header"

const page = () => {
  return (
  <>
    <Header />
    <div>Water Type Pokemons</div>
  </>
  )
}

export default page