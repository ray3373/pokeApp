import React from "react";

const Types = () => {
  return (
    <>
    Type Page
    </>
  )
}

export default Types;