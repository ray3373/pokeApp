"use client"

import React from "react"
import Header from "@/Components/Header"

const page = () => {
  return (
  <>
    <Header />
    <div>Grass Type Pokemons</div>
  </>
  )
}

export default page