import React from 'react'

const PokeDetailCard = () => {
  return (
    <div>PokeDetailCard</div>
  )
}

export default PokeDetailCard