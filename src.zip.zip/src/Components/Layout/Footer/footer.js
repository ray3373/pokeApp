import React from "react";

const Footer = () => {
  return (
    <div style={{display:"flex", justifyContent:"center"}}>
      Footer
    </div>
  )
}

export default Footer;